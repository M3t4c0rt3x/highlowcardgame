/** This package can be used to store Java files that are required by both client and server. */
package highlowcardgame.communication;
