package highlowcardgame.communication.messages;

/** Interface representing a message. */
public interface Message {}
