package highlowcardgame.server;

import static com.google.common.truth.Truth.assertThat;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.SequenceInputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ServerAdvancedTest {

  private static final String USER1 = "User_1";
  private static final String USER2 = "User_2";
  private ByteArrayOutputStream out;

  @BeforeEach
  public void setUp() {
    out = new ByteArrayOutputStream();
    System.setOut(new PrintStream(out));
  }

  @AfterEach
  public void tearDown() throws IOException {
    out.close();
  }

  private void feedInput(String input) {
    System.setIn(new ByteArrayInputStream(input.getBytes(StandardCharsets.UTF_8)));
  }

  private String getOutput() {
    return out.toString();
  }

  private OutputStream getNetworkOut() {
    return new ByteArrayOutputStream();
  }

  private InputStream getNetworkIn(String input) {
    return getNetworkIn(input, false);
  }

  private InputStream getNetworkIn(String input, boolean keepOpen) {
    InputStream emptyStream =
        new InputStream() {

          @Override
          public int read() {
            if (keepOpen) {
              try {
                Thread.sleep(2000);
              } catch (InterruptedException e) {
                e.printStackTrace();
              }
            }
            return -1;
          }
        };
    return new SequenceInputStream(
        new ByteArrayInputStream((input + System.lineSeparator()).getBytes(StandardCharsets.UTF_8)),
        emptyStream);
  }

  private void assertThatContainsNKeyValuePairs(String message, int numberOfPairsExpected) {
    assertThat(message).matches("[^:]*:[^:]*".repeat(numberOfPairsExpected));
  }

  @Test
  public void testServer_receivesGuessRequest_sendsPlayerGuessed() throws IOException {
    Server server = new Server();
    String joinRequest1 = "{\"messageType\":\"JoinGameRequest\",\"playerName\":\"" + USER1 + "\"}";
    String joinRequest2 = "{\"messageType\":\"JoinGameRequest\",\"playerName\":\"" + USER2 + "\"}";
    String guessRequest2 =
        "{\"messageType\":\"GuessRequest\",\"guess\":\"HIGH\",\"playerName\":\"" + USER2 + "\"}";
    InputStream networkIn1 = getNetworkIn(joinRequest1);
    OutputStream networkOut1 = getNetworkOut();
    InputStream networkIn2 = getNetworkIn(joinRequest2 + System.lineSeparator() + guessRequest2);
    OutputStream networkOut2 = getNetworkOut();
    MockSocket mockSocket1 = new MockSocket(networkIn1, networkOut1);
    MockSocket mockSocket2 = new MockSocket(networkIn2, networkOut2);
    MockServerSocket serverSocket = new MockServerSocket(List.of(mockSocket1, mockSocket2));

    try {
      server.start(serverSocket);
    } catch (NoSuchElementException e) {
      // expected, because number of incoming clients will be exhausted quickly.
    }

    String sent = networkOut2.toString();
    String[] jsonMessages = sent.split(System.lineSeparator());
    for (String message : jsonMessages) {
      if (message.matches(".*\"messageType\"\\s*:\\s*\"PlayerGuessedNotification\".*")
          && message.matches(".*\"playerGuessed\"\\s*:\\s*\"" + USER2 + "\".*")) {
        assertThat(message).matches(".*\"numNotGuessedPlayers\"\\s*:\\s*1.*");
        assertThatContainsNKeyValuePairs(message, 3);
        return;
      }
    }
    fail("No PlayerGuessedNotification for " + USER2);
  }

  @Test
  public void testServer_clientUnreachable_sendsPlayerLeft() throws IOException {
    Server server = new Server();
    String joinRequest1 = "{\"messageType\":\"JoinGameRequest\",\"playerName\":\"" + USER1 + "\"}";
    String joinRequest2 = "{\"messageType\":\"JoinGameRequest\",\"playerName\":\"" + USER2 + "\"}";
    InputStream networkIn1 = getNetworkIn(joinRequest1, true);
    OutputStream networkOut1 = getNetworkOut();
    InputStream networkIn2 = getNetworkIn(joinRequest2, false);
    OutputStream networkOut2 = getNetworkOut();
    MockSocket mockSocket1 = new MockSocket(networkIn1, networkOut1);
    MockSocket mockSocket2 = new MockSocket(networkIn2, networkOut2);
    MockServerSocket serverSocket = new MockServerSocket(List.of(mockSocket1, mockSocket2));

    try {
      server.start(serverSocket);
    } catch (NoSuchElementException | IOException e) {
      // expected, because number of incoming clients will be exhausted quickly.
    }

    String sent = networkOut1.toString();
    String[] jsonMessages = sent.split(System.lineSeparator());
    for (String message : jsonMessages) {
      if (message.matches(".*\"messageType\"\\s*:\\s*\"PlayerLeftNotification\".*")
          && message.matches(".*\"playerName\"\\s*:\\s*\"" + USER2 + "\".*")) {
        assertThat(message).matches(".*\"numPlayers\"\\s*:\\s*1.*");
        assertThatContainsNKeyValuePairs(message, 3);
        return;
      }
    }
    fail("No PlayerLeftNotification for " + USER2);
  }

  @Test
  public void testServer_multipleClientConnections() throws IOException {
    final int numUsers = 20;
    Server server = new Server();
    List<MockSocket> sockets = new ArrayList<>(numUsers);
    List<OutputStream> networkOutputs = new ArrayList<>(numUsers);
    for (int i = 1; i <= numUsers; i++) {
      String user = "U" + i;
      String joinRequest = "{\"messageType\":\"JoinGameRequest\",\"playerName\":\"" + user + "\"}";
      InputStream networkIn = getNetworkIn(joinRequest, true);
      OutputStream networkOut = getNetworkOut();
      networkOutputs.add(networkOut);
      sockets.add(new MockSocket(networkIn, networkOut));
    }
    MockServerSocket serverSocket = new MockServerSocket(sockets);

    try {
      server.start(serverSocket);
    } catch (NoSuchElementException | IOException e) {
      // expected, because number of incoming clients will be exhausted quickly.
    }

    for (int i = 1; i <= networkOutputs.size(); i++) {
      boolean found = false;
      String sent = networkOutputs.get(i - 1).toString();
      String[] jsonMessages = sent.split(System.lineSeparator());
      for (String message : jsonMessages) {
        if (message.matches(".*\"messageType\"\\s*:\\s*\"PlayerJoinedNotification\".*")
            && message.matches(
                ".*\"newPlayerName\"\\s*:\\s*\"U" + networkOutputs.size() + "\".*")) {
          assertThat(message).matches(".*\"numPlayers\"\\s*:\\s*[0-9]+.*");
          assertThatContainsNKeyValuePairs(message, 3);
          found = true;
          break;
        }
      }
      Assertions.assertTrue(
          found,
          "User U"
              + i
              + " did not receive PlayerJoinedNotification for user U"
              + networkOutputs.size());
    }
  }
}
